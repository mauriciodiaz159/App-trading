# app.py - Simple Flask API that returns trading signals for a given symbol (Binance)
import os
from flask import Flask, request, jsonify
import ccxt
import pandas as pd
import pandas_ta as ta
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

BINANCE_API_KEY = os.getenv("BINANCE_API_KEY", "")
BINANCE_SECRET = os.getenv("BINANCE_SECRET", "")

exchange = ccxt.binance({
    'enableRateLimit': True,
    'apiKey': BINANCE_API_KEY,
    'secret': BINANCE_SECRET,
})

app = Flask(__name__)

def fetch_ohlcv(symbol="BTC/USDT", timeframe="1h", limit=200):
    ohlcv = exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    df = pd.DataFrame(ohlcv, columns=["timestamp","open","high","low","close","volume"])
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('timestamp', inplace=True)
    return df

def compute_indicators(df):
    df = df.copy()
    df['ema12'] = ta.ema(df['close'], length=12)
    df['ema26'] = ta.ema(df['close'], length=26)
    macd = ta.macd(df['close'])
    df = pd.concat([df, macd], axis=1)
    df['rsi14'] = ta.rsi(df['close'], length=14)
    return df

def generate_signal(df):
    latest = df.iloc[-1]
    prev = df.iloc[-2]

    signal = "HOLD"
    reasons = []

    # EMA crossover
    if prev['ema12'] <= prev['ema26'] and latest['ema12'] > latest['ema26']:
        signal = "BUY"
        reasons.append("EMA12 crossed above EMA26")
    elif prev['ema12'] >= prev['ema26'] and latest['ema12'] < latest['ema26']:
        signal = "SELL"
        reasons.append("EMA12 crossed below EMA26")

    # RSI check
    if pd.notnull(latest.get('rsi14')):
        if latest['rsi14'] < 30:
            reasons.append(f"RSI={latest['rsi14']:.1f} (oversold)")
            if signal == "HOLD":
                signal = "BUY (weak)"
        elif latest['rsi14'] > 70:
            reasons.append(f"RSI={latest['rsi14']:.1f} (overbought)")
            if signal == "HOLD":
                signal = "SELL (weak)"

    # MACD histogram confirmation (if present)
    if 'MACDh_12_26_9' in df.columns:
        if latest['MACDh_12_26_9'] > 0 and signal.startswith("BUY"):
            reasons.append("MACD histogram positive (confirming)")
        elif latest['MACDh_12_26_9'] < 0 and signal.startswith("SELL"):
            reasons.append("MACD histogram negative (confirming)")

    if not reasons:
        reasons.append("No strong signals")

    return {"signal": signal, "reasons": reasons, "price": float(latest['close'])}

@app.route("/signals", methods=["GET"])
def signals():
    symbol = request.args.get("symbol", "BTC/USDT")
    timeframe = request.args.get("timeframe", "1h")
    limit = int(request.args.get("limit", 200))
    try:
        df = fetch_ohlcv(symbol=symbol, timeframe=timeframe, limit=limit)
        df = compute_indicators(df)
        result = generate_signal(df)
        return jsonify({
            "symbol": symbol,
            "timeframe": timeframe,
            "timestamp": datetime.utcnow().isoformat()+"Z",
            "result": result
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv('PORT', 5000)), debug=True)
