# Trading Signal App (minimal)

Pequeña app que consulta precios desde Binance (ccxt), calcula indicadores (EMA, RSI, MACD) y expone una API `/signals` que devuelve una señal simple (BUY / SELL / HOLD) y las razones.

## Archivos principales
- `app.py` - servidor Flask con endpoint `/signals`
- `requirements.txt` - dependencias
- `Dockerfile` - para crear una imagen Docker
- `.env.example` - variables de entorno de ejemplo

## Endpoints
- `GET /signals?symbol=BTC/USDT&timeframe=1h&limit=200`
  - `symbol` (opcional) par de mercado, por defecto `BTC/USDT`
  - `timeframe` (opcional) timeframe aceptado por ccxt (1m,5m,15m,1h,4h,1d...), por defecto `1h`
  - `limit` (opcional) cantidad de velas a descargar, por defecto `200`

Ejemplo:
```
curl "http://localhost:5000/signals?symbol=BTC/USDT&timeframe=1h"
```

## Ejecutar localmente (virtualenv)
1. Crear virtualenv
   ```
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   ```
2. Instalar dependencias
   ```
   pip install -r requirements.txt
   ```
3. Crear `.env` si quieres (puede usarse sin claves para datos públicos)
4. Correr
   ```
   python app.py
   ```
5. Abrir `http://localhost:5000/signals?symbol=BTC/USDT&timeframe=1h`

## Ejecutar con Docker
```
docker build -t trading-signal-app .
docker run -p 5000:5000 --env-file .env --name trading-signal-app trading-signal-app
```

## Notas y advertencias
- Esta es una plantilla educativa y **NO** es asesoramiento financiero.
- Testear en testnet / paper trading antes de operar en real.
- No subir claves a repos públicos.
